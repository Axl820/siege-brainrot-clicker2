SIEGE BRAINROT CLICKER - ONLINE SERVER

1. Put index.html, server.js and package.json in the same folder.
2. Install Node.js.
3. Open a terminal in this folder.
4. Run:
   npm start
5. Open:
   http://localhost:3000

Your existing HTML already calls:
- POST /api/ping
- POST /api/score
- GET /api/leaderboard
- GET /api/leaderboard?region=eu

For a public game, upload this folder to a Node.js hosting service.
