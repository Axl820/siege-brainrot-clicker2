const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const scoresFile = path.join(ROOT, "scores.json");

let scores = [];
let online = new Map(); // name -> last ping timestamp

try {
  scores = JSON.parse(fs.readFileSync(scoresFile, "utf8"));
  if (!Array.isArray(scores)) scores = [];
} catch {
  scores = [];
}

function saveScores() {
  fs.writeFileSync(scoresFile, JSON.stringify(scores, null, 2));
}

function cleanName(name) {
  return String(name || "").trim().slice(0, 20);
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 10000) req.destroy();
    });
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}

function cleanupOnline() {
  const cutoff = Date.now() - 15000;
  for (const [name, time] of online) {
    if (time < cutoff) online.delete(name);
  }
}

function leaderboard(region) {
  let list = scores.slice();
  if (region === "eu") {
    list = list.filter(x => x.region === "eu");
  }
  list.sort((a, b) => (b.score || 0) - (a.score || 0));
  return list.slice(0, 50).map((p, i) => ({
    rank: i + 1,
    name: p.name,
    score: p.score || 0,
    region: p.region || "global"
  }));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    });
    return res.end();
  }

  if (url.pathname === "/api/ping" && req.method === "POST") {
    try {
      const body = await readBody(req);
      const name = cleanName(body.name);
      if (name) online.set(name, Date.now());
      cleanupOnline();
      return json(res, 200, { online: [...online.keys()].sort() });
    } catch {
      return json(res, 400, { error: "Invalid request" });
    }
  }

  if (url.pathname === "/api/score" && req.method === "POST") {
    try {
      const body = await readBody(req);
      const name = cleanName(body.name);
      const score = Math.max(0, Math.floor(Number(body.score) || 0));
      const region = body.region === "eu" ? "eu" : "global";

      if (!name) return json(res, 400, { error: "Name required" });

      const existing = scores.find(
        x => String(x.name).toLowerCase() === name.toLowerCase()
      );

      if (existing) {
        if (score > (existing.score || 0)) existing.score = score;
        existing.region = region;
      } else {
        scores.push({ name, score, region });
      }

      scores.sort((a, b) => (b.score || 0) - (a.score || 0));
      scores = scores.slice(0, 1000);
      saveScores();

      cleanupOnline();
      return json(res, 200, { ok: true });
    } catch {
      return json(res, 400, { error: "Invalid request" });
    }
  }

  if (url.pathname === "/api/leaderboard" && req.method === "GET") {
    cleanupOnline();
    const region = url.searchParams.get("region");
    return json(res, 200, {
      players: leaderboard(region),
      online: [...online.keys()].sort()
    });
  }

  // Serve the game itself.
  let filePath = url.pathname === "/" ? "/index.html" : url.pathname;
  filePath = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, "");
  const fullPath = path.join(ROOT, filePath);

  if (!fullPath.startsWith(ROOT)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(fullPath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Not found");
    }

    const ext = path.extname(fullPath).toLowerCase();
    const types = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".svg": "image/svg+xml",
      ".ico": "image/x-icon"
    };

    res.writeHead(200, {
      "Content-Type": types[ext] || "application/octet-stream"
    });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`SIEGE BRAINROT CLICKER server running on port ${PORT}`);
});
